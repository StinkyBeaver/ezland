chmod +x ~/.config/waybar/scripts/static_ssid.sh
