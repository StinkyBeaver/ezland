#!/bin/bash
swaylock -c 00000088
