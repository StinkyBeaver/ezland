# hyprtrails

A neat, but useless plugin to add trails behind windows:

https://github.com/hyprwm/hyprland-plugins/assets/43317083/6c31b839-92cd-4510-bb12-110d77dd5b44

Maybe isn't the most efficient. The curve-related settings are only for advanced users.
Be warned they _incredibly_ impact performance.

Only setting you may want to change:
```ini
plugin {
    hyprtrails {
        color = rgba(ffaa00ff)
    }
}

```
